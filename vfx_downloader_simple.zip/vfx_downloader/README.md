# VFX Video Downloader

A minimal Flask website: one URL field, download status, and a download link.

## Run locally in Termux

```bash
pkg update -y
pkg install python ffmpeg deno -y
cd vfx_downloader
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Deploy free on Render

1. Create a GitHub account and a new repository.
2. Upload the contents of this folder to the repository.
3. In Render, choose **New > Blueprint** and connect that repository.
4. Render reads `render.yaml` and builds using the included Dockerfile.
5. Open the service URL after deployment.

## Free hosting limitations

Render's free web service can sleep after inactivity. Its local filesystem is ephemeral; downloaded videos may disappear after restart/redeploy and are not persistent storage. Free instances also have resource and execution limits, so large/long videos may fail. This project does not include persistent storage.

## Important

- Only download public content you own or are authorized to download.
- Respect copyright and the source platform's terms.
- The app intentionally allows only public HTTPS URLs from YouTube, Instagram, and TikTok.
- Do not use this basic starter as a production service without authentication, rate limits, abuse prevention, and stronger operational controls.
