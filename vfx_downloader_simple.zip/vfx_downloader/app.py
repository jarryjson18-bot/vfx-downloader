import os, re, uuid, threading, logging
from pathlib import Path
from urllib.parse import urlparse
from flask import Flask, render_template, request, jsonify, send_from_directory, abort
import yt_dlp

ROOT = Path(__file__).resolve().parent
DOWNLOADS = ROOT / "downloads"
DOWNLOADS.mkdir(exist_ok=True)
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024

ALLOWED_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
    "instagram.com", "www.instagram.com",
    "tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com"
}
jobs = {}
lock = threading.Lock()

def valid_url(value):
    try:
        p = urlparse(value.strip())
        host = (p.hostname or "").lower()
        return p.scheme == "https" and any(host == h or host.endswith("." + h) for h in ALLOWED_HOSTS)
    except Exception:
        return False

def worker(job_id, url):
    try:
        opts = {
            "outtmpl": str(DOWNLOADS / f"{job_id}_%(title).70s-%(id)s.%(ext)s"),
            "format": "best[ext=mp4]/best",
            "merge_output_format": "mp4",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "retries": 5,
            "fragment_retries": 5,
        }
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
        matches = list(DOWNLOADS.glob(job_id + "_*"))
        if not matches:
            raise RuntimeError("Download complete hua lekin file nahi mili.")
        with lock:
            jobs[job_id] = {"status": "done", "file": matches[0].name}
    except Exception as exc:
        logging.exception("Download failed")
        with lock:
            jobs[job_id] = {"status": "error", "message": str(exc)[:300]}

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/api/download")
def start_download():
    url = request.form.get("url", "").strip()
    if not valid_url(url):
        return jsonify(ok=False, error="YouTube, Instagram ya TikTok ka valid public HTTPS URL paste karein."), 400
    job_id = uuid.uuid4().hex
    with lock:
        jobs[job_id] = {"status": "working"}
    threading.Thread(target=worker, args=(job_id, url), daemon=True).start()
    return jsonify(ok=True, job_id=job_id)

@app.get("/api/status/<job_id>")
def status(job_id):
    with lock:
        item = jobs.get(job_id)
    if not item:
        return jsonify(status="missing"), 404
    result = dict(item)
    if result.get("status") == "done":
        result["download_url"] = f"/files/{result['file']}"
    return jsonify(result)

@app.get("/files/<path:filename>")
def get_file(filename):
    # Only serve files created in this app's download directory.
    path = (DOWNLOADS / filename).resolve()
    if path.parent != DOWNLOADS.resolve() or not path.is_file():
        abort(404)
    return send_from_directory(DOWNLOADS, filename, as_attachment=True)

@app.get("/health")
def health():
    return {"ok": True}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
